package com.miniproject.govtech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GovtechApplication {

	public static void main(String[] args) {
		SpringApplication.run(GovtechApplication.class, args);
	}

}
